class Menu {

    constructor(app, startGame) {
        this.firstMenuContainer;
        const self = this
        this.init = function () {
            this.generalContainer = createContainer(app.stage)
            this.firstMenuContainer = createContainer(this.generalContainer)
            this.rulesContainer = createContainer()
            this.controlsContainer = createContainer()
            createLabel(this.firstMenuContainer, "Reach the moon", app.styles.h1, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.3,
                centered: true
            })
            createButton(this.firstMenuContainer, "Start game", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.5,
                centered: true
            }, startGame)
            createButton(this.firstMenuContainer, "Rules", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.7,
                centered: true
            }, this.showRules)

            createLabel(this.rulesContainer, "Rules", app.styles.h1, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.1,
                centered: true
            })
            createLabel(this.rulesContainer, "Reach the moon before the times expires! Try to avoid the planets! ", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.2,
                centered: true
            })
            createLabel(this.rulesContainer, "Reach the moon before the times expires! Try to avoid the planets! ", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.2,
                centered: true
            })
            createButton(this.rulesContainer, "Controls", app.styles.h2, {
                x: app.renderer.width * 0.1,
                y: app.renderer.height * 0.9,
                centered: true
            }, this.showControls)

            createButton(this.rulesContainer, "Start game", app.styles.h2, {
                x: app.renderer.width * 0.8,
                y: app.renderer.height * 0.9,
                centered: true
            }, startGame)

            createLabel(this.controlsContainer, "Controls", app.styles.h1, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.1,
                centered: true
            })
            createLabel(this.controlsContainer, "P: Pause/Resume game", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.2,
                centered: true
            })
            createLabel(this.controlsContainer, "=>: Turn rocket to right", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.25,
                centered: true
            })
            createLabel(this.controlsContainer, "<=: Turn rocket to left", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.3,
                centered: true
            })
            createLabel(this.controlsContainer, "C: Use coffee", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.35,
                centered: true
            })
            createLabel(this.controlsContainer, "Esc: Open menu", app.styles.h2, {
                x: app.renderer.width / 2,
                y: app.renderer.height * 0.4,
                centered: true
            })
            createButton(this.controlsContainer, "Rules", app.styles.h2, {
                x: app.renderer.width * 0.1,
                y: app.renderer.height * 0.9,
                centered: true
            }, this.hideControls)
            createButton(this.controlsContainer, "Start game", app.styles.h2, {
                x: app.renderer.width * 0.8,
                y: app.renderer.height * 0.9,
                centered: true
            }, startGame)

            let i = 0
            app.planetsPrototypes.forEach(element => {
                const diameter = app.renderer.width / 25
                createPlanet(this.rulesContainer, element.texture, element.description  , app.styles.text, {
                    x: app.renderer.width / 3,
                    y: app.renderer.height * 0.3 + diameter * 1.3 * i,
                    width: diameter,
                    height: diameter
                })
                i+=1;
            });

            window.addEventListener('keydown', this.gameKeyBinding);
            app.ticker.add(this.onTick)
        }

        this.onTick = function () {
            app.bk.move()
        }

        this.showFirstMenu = function () {
            self.generalContainer.removeChild(self.rulesContainer)
            self.generalContainer.addChild(self.firstMenuContainer)
            window.removeEventListener('keydown', self.rulesBinding);
            window.addEventListener('keydown', self.gameKeyBinding);
        }

        this.showRules = function () {
            self.generalContainer.removeChild(self.firstMenuContainer)
            self.generalContainer.addChild(self.rulesContainer)
            window.addEventListener('keydown', self.gameKeyBinding);
            window.removeEventListener('keydown', self.rulesBinding);
        }

        this.showControls = function () {
            self.generalContainer.removeChild(self.rulesContainer)
            self.generalContainer.addChild(self.controlsContainer)
        }

        this.hideControls = function () {
            self.generalContainer.addChild(self.rulesContainer)
            self.generalContainer.removeChild(self.controlsContainer)
        }

        this.destroy = function () {
            app.stage.removeChild(this.generalContainer)
            app.ticker.remove(this.onTick)
            window.removeEventListener('keydown', this.gameKeyBinding);
        }
        this.gameKeyBinding = function (e) {
            if (e.code == "KeyS") {
                startGame()
            }
        }

        this.rulesBinding = function (e) {
            if (e.code == "Escape") {
                self.showFirstMenu()
            }
        }

        const createPlanet = function (container, texture, text, style, config) {
            const spriteContainer = createContainer(container, config);

            const sprite = createSprite(spriteContainer, texture, {
                x: 0,
                y: 0,
                width: config.width,
                height: config.height
            })

            const label = createLabel(spriteContainer, text, style, {
                x: sprite.width + 30,
                y: 0
            })
        }

        
    }
}